#include "include/sqlcipher_flutter_libs/sqlite3_flutter_libs_plugin.h"

void Sqlite3FlutterLibsPluginRegisterWithRegistrar(
    FlutterDesktopPluginRegistrarRef registrar) {

}
