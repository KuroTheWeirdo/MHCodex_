package com.example.flutter_libs

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
