#import <FlutterMacOS/FlutterMacOS.h>

@interface Sqlite3FlutterLibsPlugin : NSObject<FlutterPlugin>
@end
